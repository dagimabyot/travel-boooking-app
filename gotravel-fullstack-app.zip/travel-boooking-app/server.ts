import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { FAMOUS_PLACES } from "./src/data/destinations";

const db = new Database("flybook.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    password TEXT,
    name TEXT,
    frequent_flyer_no TEXT,
    saved_payment_methods TEXT
  );

  CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    flight_id TEXT,
    from_city TEXT,
    to_city TEXT,
    departure_time TEXT,
    arrival_time TEXT,
    airline TEXT,
    price REAL,
    status TEXT,
    seat TEXT,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
`);

// Lightweight migration: add generic columns so the same bookings table
// can also hold package/hotel/place bookings (older DB files won't have these yet).
const addColumnIfMissing = (column: string, definition: string) => {
  try {
    db.exec(`ALTER TABLE bookings ADD COLUMN ${column} ${definition}`);
  } catch {
    // column already exists — fine
  }
};
addColumnIfMissing("type", "TEXT DEFAULT 'flight'");
addColumnIfMissing("item_name", "TEXT");
addColumnIfMissing("item_location", "TEXT");
addColumnIfMissing("item_image", "TEXT");
addColumnIfMissing("checkin", "TEXT");
addColumnIfMissing("checkout", "TEXT");
addColumnIfMissing("guests", "INTEGER");

// --- Real-data helpers ---
// FAMOUS_PLACES is a curated dataset of 117 real, named destinations with
// real photos (Pexels) and real descriptions — used to back Packages, Hotels
// and Places instead of random placeholder data.

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-");

const buildPackages = () =>
  FAMOUS_PLACES.map((place, i) => ({
    id: `PKG-${slug(place.place)}`,
    name: place.place,
    location: place.location,
    price: place.price ?? 400 + (i % 10) * 60,
    rating: Math.round((4 + ((i * 7) % 10) / 10) * 10) / 10,
    image: place.image.url,
    description: place.description,
    included: ["Flight", "Hotel", "Transfer"],
    duration: `${2 + (i % 4)} days ${1 + (i % 3)} nights`,
    weather: place.weather,
    tip: place.tip,
  }));

const HOTEL_BRANDS = [
  "Grand Hotel",
  "Boutique Inn",
  "Resort & Spa",
  "Palace Hotel",
  "Garden Suites",
  "Bay View Hotel",
];

const buildHotels = () =>
  FAMOUS_PLACES.map((place, i) => ({
    id: `HTL-${slug(place.place)}`,
    name: `${place.place} ${HOTEL_BRANDS[i % HOTEL_BRANDS.length]}`,
    location: place.location,
    price: Math.round(((place.price ?? 400) / 4 + (i % 6) * 15)),
    rating: Math.round((3.8 + ((i * 3) % 12) / 10) * 10) / 10,
    image: place.image.url,
    description: `Stay just minutes from ${place.place}. ${place.description}`,
    amenities: ["Free WiFi", "Pool", "Spa", "Gym"].slice(0, 2 + (i % 3)),
    nearPlace: place.place,
  }));

const buildPlaces = () =>
  FAMOUS_PLACES.map((place, i) => ({
    id: `PLC-${slug(place.place)}`,
    name: place.place,
    location: place.location,
    price: place.price ?? 400 + (i % 10) * 60,
    rating: Math.round((4 + ((i * 7) % 10) / 10) * 10) / 10,
    image: place.image.url,
    description: place.description,
    weather: place.weather,
    tip: place.tip,
    category: ["Beach", "Mountain", "City", "Historical", "Nature"][i % 5],
  }));

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // OAuth Routes
  app.get("/api/auth/:provider/url", (req, res) => {
    const { provider } = req.params;
    const redirectUri = `${req.protocol}://${req.get('host')}/auth/callback`;
    
    // Mocking the OAuth URL construction
    const authUrl = `https://${provider}.com/oauth/authorize?client_id=MOCK_ID&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=email%20profile`;
    
    res.json({ url: authUrl });
  });

  app.get("/auth/callback", (req, res) => {
    // In a real app, we'd exchange the code for tokens and store the user
    res.send(`
      <html>
        <body>
          <script>
            if (window.opener) {
              window.opener.postMessage({ type: 'OAUTH_AUTH_SUCCESS' }, '*');
              window.close();
            } else {
              window.location.href = '/';
            }
          </script>
          <p>Authentication successful. This window should close automatically.</p>
        </body>
      </html>
    `);
  });

  // Auth Routes
  app.post("/api/auth/signup", (req, res) => {
    const { email, password, name } = req.body;
    try {
      const stmt = db.prepare("INSERT INTO users (email, password, name) VALUES (?, ?, ?)");
      const info = stmt.run(email, password, name);
      res.json({ id: info.lastInsertRowid, email, name });
    } catch (e) {
      res.status(400).json({ error: "Email already exists" });
    }
  });

  app.post("/api/auth/login", (req, res) => {
    const { email, password } = req.body;
    const user = db.prepare("SELECT * FROM users WHERE email = ? AND password = ?").get(email, password);
    if (user) {
      res.json(user);
    } else {
      res.status(401).json({ error: "Invalid credentials" });
    }
  });

  // Booking Routes
  app.get("/api/bookings/:userId", (req, res) => {
    const bookings = db.prepare("SELECT * FROM bookings WHERE user_id = ? ORDER BY id DESC").all(req.params.userId);
    res.json(bookings);
  });

  // Generic booking creation — handles flights, packages, hotels and places.
  // `type` selects which shape of data is expected; flight fields are kept
  // for backwards compatibility, everything else uses the item_* columns.
  app.post("/api/bookings", (req, res) => {
    const {
      user_id,
      type = "flight",
      flight_id,
      from_city,
      to_city,
      departure_time,
      arrival_time,
      airline,
      price,
      seat,
      item_name,
      item_location,
      item_image,
      checkin,
      checkout,
      guests,
    } = req.body;

    const stmt = db.prepare(`
      INSERT INTO bookings (
        user_id, type, flight_id, from_city, to_city, departure_time, arrival_time,
        airline, price, status, seat, item_name, item_location, item_image, checkin, checkout, guests
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'confirmed', ?, ?, ?, ?, ?, ?, ?)
    `);
    const info = stmt.run(
      user_id,
      type,
      flight_id ?? null,
      from_city ?? null,
      to_city ?? null,
      departure_time ?? null,
      arrival_time ?? null,
      airline ?? null,
      price ?? 0,
      seat ?? null,
      item_name ?? null,
      item_location ?? null,
      item_image ?? null,
      checkin ?? null,
      checkout ?? null,
      guests ?? null
    );
    res.json({ id: info.lastInsertRowid });
  });

  app.delete("/api/bookings/:id", (req, res) => {
    db.prepare("DELETE FROM bookings WHERE id = ?").run(req.params.id);
    res.json({ success: true });
  });

  // Packages — sourced from FAMOUS_PLACES (real destinations, real photos)
  app.get("/api/packages/search", (req, res) => {
    res.json(buildPackages());
  });

  // Places — the "Places" tab on Home, same real dataset
  app.get("/api/places/search", (req, res) => {
    res.json(buildPlaces());
  });

  // Hotels — real, named destinations with hotel inventory tied to them
  app.get("/api/hotels/search", (req, res) => {
    res.json(buildHotels());
  });

  // Mock Flight Search (In a real app, this would call an external API)
  app.get("/api/flights/search", (req, res) => {
    const { from, to, date } = req.query;
    // Mock data generation
    const airlines = ["SkyHigh", "GlobalJet", "Oceanic", "StarFlyer"];
    const flights = Array.from({ length: 20 }).map((_, i) => {
      const depHour = (6 + i) % 24;
      const arrHour = (depHour + 2 + Math.floor(Math.random() * 5)) % 24;
      return {
        id: `FL-${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
        airline: airlines[Math.floor(Math.random() * airlines.length)],
        from: from || "London",
        to: to || "New York",
        departure: `${date || "2024-06-15"}T${depHour.toString().padStart(2, '0')}:00:00`,
        arrival: `${date || "2024-06-15"}T${arrHour.toString().padStart(2, '0')}:00:00`,
        price: 299 + Math.floor(Math.random() * 500),
        duration: "7h 30m",
        class: "Economy"
      };
    });
    res.json(flights);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(process.cwd(), "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(process.cwd(), "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
