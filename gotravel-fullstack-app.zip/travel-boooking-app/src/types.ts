export interface User {
  id: number;
  email: string;
  name: string;
  frequent_flyer_no?: string;
  saved_payment_methods?: string;
}

export interface Flight {
  id: string;
  airline: string;
  from: string;
  to: string;
  departure: string;
  arrival: string;
  price: number;
  duration: string;
  class: string;
}

export interface Booking {
  id: number;
  user_id: number;
  type: 'flight' | 'package' | 'hotel' | 'place';
  flight_id?: string;
  from_city?: string;
  to_city?: string;
  departure_time?: string;
  arrival_time?: string;
  airline?: string;
  price: number;
  status: string;
  seat?: string;
  item_name?: string;
  item_location?: string;
  item_image?: string;
  checkin?: string;
  checkout?: string;
  guests?: number;
}

export interface AppNotification {
  id: string;
  title: string;
  body: string;
  time: string;
  read: boolean;
  type: 'booking' | 'reminder' | 'system';
}

export interface Package {
  id: string;
  name: string;
  location: string;
  price: number;
  rating: number;
  image: string;
  description: string;
  included: string[];
  duration: string;
  kind?: 'package' | 'place';
}

export interface Hotel {
  id: string;
  name: string;
  location: string;
  price: number;
  rating: number;
  image: string;
  description: string;
  amenities: string[];
  nearPlace?: string;
}

export interface Place {
  id: string;
  name: string;
  location: string;
  price: number;
  rating: number;
  image: string;
  description: string;
  weather: string;
  tip: string;
  category: string;
}

export type Screen = 
  | 'splash' 
  | 'auth-welcome' | 'auth-email' | 'auth-password' | 'auth-signup' | 'auth-forgot' | 'auth-verify' 
  | 'home' | 'packages' | 'package-details' | 'place-details' | 'flight-search' | 'flight-results' | 'flight-details' 
  | 'hotel-search' | 'hotel-results' | 'hotel-details' 
  | 'seat-selection' | 'check-availability' | 'payment' | 'confirmation' | 'ticket'
  | 'my-trips' | 'saved' | 'profile' | 'settings' | 'alerts';
